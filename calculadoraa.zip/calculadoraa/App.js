import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Keyboard } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function App() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [resultado, setResultado] = useState(null);

  const operacoes = ['+', '-', '*', '/','% '];

  const calcular = (operacao) => {
    Keyboard.dismiss();
    const n1 = parseFloat(num1);
    const n2 = parseFloat(num2);

    if (isNaN(n1) || isNaN(n2)) return;

    let res = 0;
    switch (operacao) {
      case '+': res = n1 + n2; break;
      case '-': res = n1 - n2; break;
      case '*': res = n1 * n2; break;
      case '/': res = n2 !== 0 ? n1 / n2 : 'Erro'; break;
      case '%': res = n1 * n2 / 100; break;
    }
    setResultado(res);
  };

  // add fnç rest
  const resetar = () => {
    setNum1('');
    setNum2('');
    setResultado(null);
    Keyboard.dismiss();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>😁Calculadora😁</Text>
      
      <View style={styles.card}>
        <TextInput style={styles.input} keyboardType="numeric" placeholder="Insira um valor Ex:1,2,3..." value={num1} onChangeText={setNum1} />
        <TextInput style={styles.input} keyboardType="numeric" placeholder="Insira um valor Ex:1,2,3..." value={num2} onChangeText={setNum2} />
        
        <View style={styles.linhaBotoes}>
          {operacoes.map((op) => (
            <TouchableOpacity key={op} style={styles.botao} onPress={() => calcular(op)}>
              <LinearGradient colors={['#6366f1', '#4f46e5']} style={styles.gradient}>
                <Text style={styles.textoBotao}>{op}</Text>
              </LinearGradient>
            </TouchableOpacity>
          ))}

          {/*add bt do mesmo jeito dos outros*/}
          <TouchableOpacity style={styles.botao} onPress={resetar}>
            <LinearGradient colors={['#ef4444', '#dc2626']} style={styles.gradient}>
              <Text style={styles.textoBotao}>C</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {resultado !== null && (
          <View style={styles.resultadoContainer}>
            <Text style={styles.labelResultado}>Resultado</Text>
            <Text style={styles.valorResultado}>{resultado}</Text>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20, backgroundColor: '#6959CD' },
  titulo: { fontSize: 32, fontWeight: '800', textAlign: 'center', marginBottom: 40, color: '#FF0000' },
  card: { backgroundColor: '#FF0000', padding: 25, borderRadius: 25, shadowColor: '#000', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.1, shadowRadius: 20, elevation: 8 },
  input: { backgroundColor: '#f1f5f9', padding: 18, marginBottom: 15, borderRadius: 15, fontSize: 16, color: '#334155' },
  linhaBotoes: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 },
  botao: { flex: 1, marginHorizontal: 5, borderRadius: 50, overflow: 'hidden' },
  gradient: { paddingVertical: 9, alignItems: 'center' },
  textoBotao: { color: '#fff', fontSize: 24, fontWeight: 'bold' },
  resultadoContainer: { marginTop: 30, alignItems: 'center', borderTopWidth: 1, borderTopColor: '#e2e8f0', paddingTop: 20 },
  labelResultado: { color: '#64748b', fontSize: 14, textTransform: 'uppercase', letterSpacing: 1 },
  valorResultado: { fontSize: 48, fontWeight: '700', color: '#4B0082' }
});