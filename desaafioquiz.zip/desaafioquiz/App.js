import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
  Image,
} from 'react-native';

const QUIZ = [
  {
    id: 1,
    pergunta: 'Qual o nome do protagonista de Naruto?',
    opcoes: ['Sasuke Uchiha', 'Naruto Uzumaki', 'Kakashi Hatake', 'Jiraiya'],
    respostaCerta: 1,
    imagem: 'https://imgs.search.brave.com/2qxQEtwynmOQBZPYqZjqiyCIxMNM4tezKmb3ljrvlok/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly93MC5w/ZWFrcHguY29tL3dh/bGxwYXBlci82ODkv/MjY2L0hELXdhbGxw/YXBlci1uYXJ1dG8t/dXp1bWFraS1rYWth/c2hpLWhhdGFrZS1p/dGFjaGktdWNoaWhh/LXNha3VyYS1oYXJ1/bm8tZ2FhcmEtaGlu/YXRhLWh5dWdhLW1h/ZGFyYS11Y2hpaGEt/c2FzdWtlLXVjaGlo/YS1uYXJ1dG8uanBn',
  },
  {
    id: 2,
    pergunta: 'Em One Piece, qual é o nome do chapéu do Luffy?',
    opcoes: ['Chapéu de Palha', 'Chapéu Preto', 'Chapéu de Couro', 'Chapéu Vermelho'],
    respostaCerta: 0,
    imagem: 'https://imgs.search.brave.com/IP-ui5bweizakpC6f2rTlVQvSGpahDC0aZ5J-0eK0jE/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9odHRw/Mi5tbHN0YXRpYy5j/b20vRF9RX05QXzJY/XzY3MjYzOC1NTEI3/OTgwODk0NjE3OV8x/MDIwMjQtRS1jaGFw/ZXUtdGlwby1kby1s/dWZmeS1kby1vbmUt/cGllY2UtY29zcGxh/eS1iZ3MtY29taWMt/YW5pbWUud2VicA',
  },
  {
    id: 3,
    pergunta: 'Qual anime se passa na Academia Jujutsu de Feitiçaria?',
    opcoes: ['Demon Slayer', 'Jujutsu Kaisen', 'Attack on Titan', 'Tokyo Ghoul'],
    respostaCerta: 1,
    imagem: 'https://imgs.search.brave.com/ykR2MrPbws75-boD-AlwMynnFXLZLVhtYqMrF0j2A2s/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9zLmFm/aWNpb25hZG9zLmNv/bS5ici9pbWFnZW5z/L29zLTI1LWFuaW1l/cy1tYWlzLWFzc2lz/dGlkb3Mtbm8tbXVu/ZG8tYXRlLWFnb3Jh/X2MuanBn',
  },
  {
    id: 4,
    pergunta: 'Quem é o "Titã Fundador" em Attack on Titan?',
    opcoes: ['Eren Yeager', 'Armin Arlert', 'Historia Reiss', 'Levi Ackerman'],
    respostaCerta: 2,
    imagem: 'https://imgs.search.brave.com/JLnAjBYLdXPCEIIBK0CbwiaG0rxqiZk1bq6CGgmqrZ4/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly93YWxs/cGFwZXJjYXZlLmNv/bS93cC93cDE4Mzc1/NDcuanBn',
  },
  {
    id: 5,
    pergunta: 'Em Demon Slayer, qual é a respiração principal de Tanjiro?',
    opcoes: ['Respiração da Água', 'Respiração do Fogo', 'Respiração do Vento', 'Respiração da Pedra'],
    respostaCerta: 0,
    imagem: 'https://imgs.search.brave.com/EA0WvVzVfWrrMJUqsjkX3-mmbGF_L4zE3XmlZk2pCic/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMyLmFscGhhY29k/ZXJzLmNvbS8xMjgv/dGh1bWJiaWctMTI4/MzQ2NC53ZWJw',
  },
  {
    id: 6,
    pergunta: 'Qual o nome do gato em Sailor Moon?',
    opcoes: ['Luna', 'Artemis', 'Diana', 'Kuro'],
    respostaCerta: 0,
    imagem: 'https://imgs.search.brave.com/8HMucJMHsj6k6hfBAGJFRPgbFG3ricfR9DAeAVKLxow/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9wcmV2/aWV3LnJlZGQuaXQv/c2FpbG9yLW1vb24t/aXMtdGhlLW9ubHkt/c2VyaWVzLWkta25v/dy13aGVyZS10aGUt/d2hpdGUtY2F0LXYw/LTY0Z3UxZ3IwaG5k/ZDEucG5nP3dpZHRo/PTY0MCZjcm9wPXNt/YXJ0JmF1dG89d2Vi/cCZzPTAxYmEwMjkz/MzBhOWQ4YTJiYWI5/YjRjYmFiNWU4Mjc2/ZmJjNGE3MDI',
  },
  {
    id: 7,
    pergunta: 'Em Dragon Ball, quem é o primeiro rival de Goku?',
    opcoes: ['Vegeta', 'Piccolo', 'Kuririn', 'Yamcha'],
    respostaCerta: 3,
    imagem: 'https://imgs.search.brave.com/RLcwqDJB7YT9nRJVmhaN06K0NwNeFGQ7MHSuBspf5og/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9iLnRo/dW1icy5yZWRkaXRt/ZWRpYS5jb20vRlhy/V2FxSUl3VDNVS3pr/cGtMN2lHaEhZLUFV/LUlfNloxYnFubGZX/endySS5qcGc',
  },
  {
    id: 8,
    pergunta: 'Qual anime tem um gato que vira ônibus?',
    opcoes: ['Meu Amigo Totoro', 'Spirited Away', 'A Viagem de Chihiro', 'O Castelo Animado'],
    respostaCerta: 0,
    imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0BOBD0RcLBmUMko_wiMi9t5eItwazzpxtIw&s',
  },
  {
    id: 9,
    pergunta: 'Em Death Note, qual o nome do caderno que mata quem tem o nome escrito nele?',
    opcoes: ['Caderno da Morte', 'Livro Sombrio', 'Diário do Fim', 'Caderno Negro'],
    respostaCerta: 0,
    imagem: 'https://imgs.search.brave.com/W5V4Mwz7ffHVim9-FMaZ22Ya7_NSfcLSOjEuxP5e7ZY/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9jZG4u/d2FsbHBhcGVyc2Fm/YXJpLmNvbS80NS8x/OC9MdzhlajkuanBn',
  },
  {
    id: 10,
    pergunta: 'Qual é o poder principal de Saitama em One Punch Man?',
    opcoes: ['Força Infinita', 'Derrotar qualquer um com um soco', 'Voar', 'Controlar o tempo'],
    respostaCerta: 1,
    imagem: 'https://imgs.search.brave.com/eziYblJbvXtW5lLfM7-rAaKLlOI17k9tJDMV6_n7XhM/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly93YWxs/cGFwZXJjYXQuY29t/L3cvZnVsbC9jLzEv/Yi8xMzIzOTQtMTky/MHgxMDgwLWRlc2t0/b3AtZnVsbC1oZC1v/bmUtcHVuY2gtbWFu/LWJhY2tncm91bmQu/anBn',
  },
];

export default function AppQuiz() {
  const [telaAtual, setTelaAtual] = useState('inicio');
  const [perguntaAtual, setPerguntaAtual] = useState(0);
  const [pontuacao, setPontuacao] = useState(0);
  const [carregando, setCarregando] = useState(false);
  const [corBotao, setCorBotao] = useState(null);
  const [ultimoClicado, setUltimoClicado] = useState(null); // guarda qual botão foi clicado
  const [bloqueado, setBloqueado] = useState(false);

  function iniciarJogo() {
    setPerguntaAtual(0);
    setPontuacao(0);
    setTelaAtual('quiz');
    setCorBotao(null);
    setUltimoClicado(null);
    setBloqueado(false);
  }

  function voltarAoInicio() {
    setTelaAtual('inicio');
  }

  function responder(indice) {
    setBloqueado(true);
    setUltimoClicado(indice); // salva qual foi clicado
    const pergunta = QUIZ[perguntaAtual];

    if (indice === pergunta.respostaCerta) {
      setCorBotao('certo');
      setPontuacao(pontuacao + 1);
    } else {
      setCorBotao('errado');
    }

    setTimeout(() => {
      setCarregando(true);
      setCorBotao(null);
      setUltimoClicado(null);
      setBloqueado(false);

      setTimeout(() => {
        setCarregando(false);
        if (perguntaAtual + 1 < QUIZ.length) {
          setPerguntaAtual(perguntaAtual + 1);
        } else {
          setTelaAtual('resultado');
        }
      }, 500);
    }, 1000);
  }

  if (telaAtual === 'inicio') {
    return (
      <View style={styles.telaCentrada}>
        <Image
          source={{ uri: 'https://imgs.search.brave.com/14bPRll-CEpReAXzK25kibzM0e8oBRaQDls51dd7HQw/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9wdC5x/dWl6dXIuY29tL19p/bWFnZT9ocmVmPWh0/dHBzOi8vc3RhdGlj/LnF1aXp1ci5jb20v/aS9iLzVhYTQzNTU5/MTRkNjkzLjI0MjMz/NDAyNWFhNDM1NTkw/MDNlZjUuMDQ5MjUy/MDkuanBnJnc9NjAw/Jmg9NjAwJmY9d2Vi/cA' }}
          style={styles.logoInicial}
        />
        <Text style={styles.tituloPrincipal}>Quiz Anime e Mangá</Text>
        <Text style={styles.subtituloInicio}>Teste seus conhecimentos</Text>
        <TouchableOpacity
          style={styles.botaoIniciar}
          onPress={iniciarJogo}
          activeOpacity={0.8}>
          <Text style={styles.textoBotaoIniciar}>INICIAR</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (telaAtual === 'resultado') {
    return (
      <View style={styles.telaCentrada}>
        <Text style={styles.iconeGrande}>🎉</Text>
        <Text style={styles.titulo}>Fim de Jogo!</Text>
        <Text style={styles.subtitulo}>
          Você acertou {pontuacao} de {QUIZ.length} perguntas.
        </Text>
        <TouchableOpacity
          style={styles.botaoAcao}
          onPress={voltarAoInicio}
          activeOpacity={0.8}>
          <Text style={styles.textoBotaoAcao}>Voltar ao Início</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (carregando) {
    return (
      <View style={styles.telaCentrada}>
        <ActivityIndicator size="large" color="#7b2cbf" />
        <Text style={styles.textoCarregando}>Validando resposta...</Text>
      </View>
    );
  }

  const pergunta = QUIZ[perguntaAtual];
  return (
    <View style={styles.tela}>
      <View style={styles.cabecalho}>
        <Text style={styles.progresso}>
          Pergunta {perguntaAtual + 1} de {QUIZ.length}
        </Text>
        <Text style={styles.pontos}>Pontos: {pontuacao}</Text>
      </View>

      <View style={styles.cartaoPergunta}>
        <Image
          source={{ uri: pergunta.imagem }}
          style={styles.imagemPergunta}
          resizeMode="cover"
        />
        <Text style={styles.textoPergunta}>{pergunta.pergunta}</Text>
      </View>

      <View style={styles.areaOpcoes}>
        {pergunta.opcoes.map((opcao, index) => (
          <TouchableOpacity
            key={index}
            style={[
              styles.botaoOpcao,
              corBotao === 'certo' && index === pergunta.respostaCerta
                ? { backgroundColor: '#d1fae5', borderColor: '#10b981' }
                : corBotao === 'errado' && index === ultimoClicado
                ? { backgroundColor: '#fecdd3', borderColor: '#ef4444' }
                : {},
            ]}
            onPress={() => responder(index)}
            activeOpacity={0.7}
            disabled={bloqueado}>
            <Text style={styles.textoOpcao}>{opcao}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  tela: { flex: 1, backgroundColor: '#f3e8ff', padding: 20, paddingTop: 60 },
  telaCentrada: {
    flex: 1,
    backgroundColor: '#f3e8ff',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  logoInicial: { width: 140, height: 140, marginBottom: 20, borderRadius: 20 },
  tituloPrincipal: {
    fontSize: 36,
    fontWeight: '900',
    color: '#5b21b6',
    marginBottom: 10,
    textAlign: 'center',
  },
  subtituloInicio: {
    fontSize: 16,
    color: '#7c3aed',
    marginBottom: 50,
    textAlign: 'center',
    paddingHorizontal: 20,
  },
  botaoIniciar: {
    backgroundColor: '#7b2cbf',
    paddingVertical: 20,
    paddingHorizontal: 40,
    borderRadius: 20,
    width: '100%',
    maxWidth: 300,
    shadowColor: '#7b2cbf',
    shadowOpacity: 0.4,
    shadowRadius: 15,
    elevation: 8,
    alignItems: 'center',
  },
  textoBotaoIniciar: {
    color: 'white',
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: 1,
  },
  cabecalho: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 30,
    paddingHorizontal: 10,
  },
  progresso: { fontSize: 16, fontWeight: '700', color: '#6b21a8' },
  pontos: { fontSize: 16, fontWeight: '800', color: '#7b2cbf' },
  cartaoPergunta: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 20,
    marginBottom: 30,
    shadowColor: '#0f172a',
    shadowOpacity: 0.05,
    shadowRadius: 15,
    elevation: 5,
  },
  imagemPergunta: {
    width: '100%',
    height: 150,
    borderRadius: 12,
    marginBottom: 15,
  },
  textoPergunta: {
    fontSize: 22,
    fontWeight: '800',
    color: '#1e293b',
    textAlign: 'center',
    lineHeight: 30,
  },
  areaOpcoes: { flex: 1 },
  botaoOpcao: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 15,
    marginBottom: 15,
    borderWidth: 2,
    borderColor: '#e9d5ff',
  },
  textoOpcao: {
    fontSize: 18,
    color: '#334155',
    fontWeight: '600',
    textAlign: 'center',
  },
  iconeGrande: { fontSize: 80, marginBottom: 20 },
  titulo: {
    fontSize: 32,
    fontWeight: '900',
    color: '#5b21b6',
    marginBottom: 10,
  },
  subtitulo: { fontSize: 18, color: '#7c3aed', marginBottom: 40 },
  botaoAcao: {
    backgroundColor: '#7b2cbf',
    paddingVertical: 18,
    paddingHorizontal: 40,
    borderRadius: 16,
    width: '100%',
    maxWidth: 300,
    alignItems: 'center',
  },
  textoBotaoAcao: { color: 'white', fontSize: 18, fontWeight: '800' },
  textoCarregando: {
    marginTop: 20,
    fontSize: 18,
    fontWeight: '600',
    color: '#7b2cbf',
  },
});
