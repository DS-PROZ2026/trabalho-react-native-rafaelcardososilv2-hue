// ==========================================
// A ÁREA DE ESTILOS (O CSS Blindado)
// ==========================================
const styles = StyleSheet.create({
  tela: {
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
    backgroundColor: '#f8fafc' 
  },
  titulo: { 
    fontSize: 28, 
    fontWeight: 'bold', 
    color: '#1e293b',
    textAlign: 'center' // Garante que não quebre feio em telas menores
  },
  subtitulo: { 
    fontSize: 16, 
    color: '#64748b', 
    marginBottom: 30,
    textAlign: 'center'
  },
  botao: { 
    backgroundColor: '#ef4444', 

    paddingVertical: 12, 
    paddingHorizontal: 20, 
    borderRadius: 8, 
    width: 200, 
    // Estes dois garantem o centro exato no Android e no iOS:
    alignItems: 'center', 
    justifyContent: 'center', 
  },
  textoBotao: { 
    color: 'white', 
    fontSize: 18, 
    fontWeight: 'bold',
    // Protege contra emojis empurrando a altura da linha:
    lineHeight: 24 
  }
});